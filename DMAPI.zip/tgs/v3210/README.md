# DMAPI V3

This DMAPI implements bridge using file output which TGS monitors for.

- [api.dm](./api.dm) contains the bulk of the API code.
- [commands.dm](./commands.dm) contains functions relating to `/datum/tgs_chat_command`s.
