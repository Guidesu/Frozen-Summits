# DMAPI V4

This DMAPI implements bridge requests using file output which TGS monitors for. It has a safe mode restriction.

- [api.dm](./api.dm) contains the bulk of the API code.
- [commands.dm](./commands.dm) contains functions relating to `/datum/tgs_chat_command`s.
